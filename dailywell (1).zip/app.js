'use strict';
const $=s=>document.querySelector(s),K='dailywell.v1',pad=n=>String(n).padStart(2,'0');
const fmt=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
const D=s=>{const[a,b,c]=s.split('-');return new Date(+a,+b-1,+c)};
const today=()=>fmt(new Date()),addD=(s,n)=>{const d=D(s);d.setDate(d.getDate()+n);return fmt(d)};
const hm=()=>{const d=new Date();return pad(d.getHours())+':'+pad(d.getMinutes())};
const def=()=>({set:{name:'',kcal:2000,water:2000,serv:1,allergy:'',avoid:'',budget:'',cook:'',ron:false,rs:'08:00',re:'21:00',ri:120,quiet:'',plan:today()},eaten:{},water:{},wk:{},wo:{},meds:[],ml:{},ov:{},fav:[],last:0});
let S;try{S=Object.assign(def(),JSON.parse(localStorage.getItem(K)||'{}'))}catch(e){S=def()}
const save=()=>localStorage.setItem(K,JSON.stringify(S));
let tab='home',mv='day',md=today(),cm=new Date(),reg=null;
const L={b:'Sarapan',l:'Makan siang',d:'Makan malam',s:'Camilan'};
const mk=a=>({n:a[0],k:a[1],p:a[2],c:a[3],f:a[4],i:a[5],s:a[6],u:a[7]});
const P={
b:[['Oatmeal Pisang & Telur Rebus',400,20,55,12,'Oat 40 g, Susu 150 ml, Pisang 1 sedang, Telur 1','Masak oat dengan susu. Iris pisang. Sajikan dengan telur rebus.','Susu → susu kedelai'],
['Nasi Uduk Mini & Telur Dadar',450,16,60,15,'Nasi uduk 100 g, Telur 1, Timun 50 g, Bawang goreng 1 sdm','Dadar telur dengan sedikit minyak. Sajikan dengan nasi dan timun.','Nasi → lontong'],
['Roti Gandum Telur Orak-arik',380,18,42,14,'Roti gandum 2 lembar, Telur 2, Tomat 1/2 buah','Orak-arik telur dengan tomat. Taruh di atas roti panggang.','Telur → tempe'],
['Bubur Ayam Sederhana',420,22,58,10,'Nasi 150 g, Ayam suwir 50 g, Daun bawang, Kecap manis 1 sdt','Masak nasi dengan air jadi bubur. Beri ayam suwir dan daun bawang.','Ayam → telur rebus'],
['Tempe Orek & Nasi Merah',430,19,58,12,'Nasi merah 100 g, Tempe 50 g, Kecap manis 1 sdm, Cabai 2','Potong tempe, tumis dengan kecap dan cabai sampai kering.','Tempe → tahu'],
['Pisang Kukus & Yogurt',320,12,55,6,'Pisang 2 buah, Yogurt plain 150 g, Madu 1 sdt','Kukus pisang 10 menit. Sajikan dengan yogurt dan madu.','Yogurt → susu'],
['Lontong Sayur Tahu',400,14,62,9,'Lontong 150 g, Tahu 80 g, Labu siam 80 g, Santan encer 50 ml','Rebus labu siam dan tahu dengan bumbu dan santan. Sajikan dengan lontong.','Tahu → tempe'],
['Bubur Kacang Hijau & Telur',380,17,55,8,'Kacang hijau 50 g, Santan encer 50 ml, Gula 1 sdt, Telur rebus 1','Rebus kacang hijau sampai empuk, beri santan dan gula. Sajikan dengan telur.','Santan → susu']].map(mk),
l:[['Nasi, Ayam Bakar Kecap & Lalapan',550,35,60,16,'Nasi 150 g, Dada ayam 100 g, Kecap manis 1 sdm, Timun & selada 80 g','Marinasi ayam dengan kecap dan bawang. Panggang/teflon 15 menit. Sajikan dengan lalapan.','Ayam → tempe'],
['Gado-gado & Telur Rebus',500,22,50,22,'Kentang 100 g, Kol & kacang panjang 100 g, Tahu 60 g, Telur 1, Bumbu kacang 2 sdm','Rebus sayur, kentang, telur. Siram bumbu kacang.','Kentang → lontong'],
['Soto Ayam & Nasi',520,30,62,14,'Nasi 120 g, Ayam suwir 80 g, Soun 20 g, Tauge 30 g, Kuah kaldu 300 ml','Rebus ayam dengan bumbu soto. Sajikan dengan soun, tauge, dan nasi.','Ayam → telur'],
['Pepes Ikan Kembung & Nasi',500,32,55,15,'Nasi 150 g, Ikan kembung 100 g, Daun kemangi, Bumbu kuning, Sayur rebus 80 g','Lumuri ikan bumbu, bungkus daun pisang, kukus 20 menit.','Ikan → tahu/tempe'],
['Tempe Tahu Bacem & Sayur Asem',480,24,60,14,'Nasi 150 g, Tempe 50 g, Tahu 50 g, Sayur asem 150 g, Gula merah 1 sdt','Rebus tempe/tahu dengan bumbu bacem. Sajikan dengan sayur asem.','Tahu → telur'],
['Tumis Daging Sapi Buncis',560,32,58,20,'Nasi 150 g, Daging sapi 80 g, Buncis 100 g, Bawang putih 2 siung','Tumis bawang, daging iris tipis, lalu buncis. Bumbui kecap dan garam.','Sapi → ayam'],
['Capcay Telur & Nasi',470,20,58,16,'Nasi 150 g, Telur 1, Wortel, Kol, Sawi 150 g, Bawang putih','Tumis sayur dengan bawang, tambah telur, sajikan dengan nasi.','Telur → tahu'],
['Pecel Sayur & Tempe Goreng',500,22,60,18,'Nasi 120 g, Bayam & tauge 120 g, Bumbu pecel 2 sdm, Tempe 50 g','Rebus sayur, siram bumbu pecel, sajikan dengan tempe goreng.','Tempe → tahu']].map(mk),
d:[['Sop Ayam Sayur',380,28,35,12,'Ayam 80 g, Wortel 50 g, Kentang 80 g, Kol 50 g, Seledri','Rebus ayam dengan bumbu, masukkan sayur sampai empuk.','Ayam → tahu'],
['Orek Tempe & Tumis Bayam',420,20,45,16,'Nasi 120 g, Tempe 60 g, Bayam 100 g, Bawang putih','Orek tempe dengan kecap. Tumis bayam sebentar.','Bayam → kangkung'],
['Tumis Tahu Brokoli',400,20,45,14,'Nasi 120 g, Tahu 100 g, Brokoli 100 g, Bawang putih','Tumis bawang, tahu, brokoli. Bumbui saus tiram/kecap.','Brokoli → sawi'],
['Semur Daging Sapi & Kentang',520,32,50,18,'Nasi 100 g, Daging sapi 80 g, Kentang 100 g, Kecap 1 sdm','Rebus daging dengan bumbu semur sampai empuk, tambah kentang.','Sapi → ayam'],
['Telur Balado & Tumis Kangkung',450,20,50,18,'Nasi 120 g, Telur 2, Kangkung 100 g, Cabai 3','Goreng telur, balur sambal cabai. Tumis kangkung.','Telur → tahu'],
['Perkedel Jagung & Sayur Bening',430,18,52,14,'Nasi 100 g, Jagung 80 g, Telur 1, Tepung 2 sdm, Bayam 100 g','Campur jagung, telur, tepung. Goreng. Sajikan dengan sayur bening.','Jagung → tahu'],
['Ikan Nila Bakar & Tumis Kangkung',480,32,45,15,'Nasi 120 g, Ikan nila 100 g, Kangkung 100 g, Jeruk nipis','Lumuri ikan bumbu, panggang 10 menit tiap sisi, tumis kangkung.','Ikan → ayam'],
['Sup Kacang Merah & Daging',470,28,50,14,'Kacang merah 60 g, Daging sapi 60 g, Wortel 50 g, Seledri','Rebus kacang merah dan daging hingga empuk dengan sayur.','Daging → ayam']].map(mk),
s:[['Buah Potong (Pepaya/Semangka)',80,1,20,0,'Buah potong 150 g','Potong dan sajikan.','Pilih buah musiman'],
['Kacang Rebus',150,8,12,8,'Kacang tanah rebus 40 g','Rebus kacang dengan garam.','Kacang → edamame'],
['Pisang Rebus',110,1,28,0,'Pisang kepok 1 buah','Rebus 10 menit.','Pisang → ubi rebus'],
['Yogurt Plain & Madu',130,8,16,4,'Yogurt 125 g, Madu 1 sdt','Campur dan sajikan.','Yogurt → susu']].map(mk)};
const W=[['Jalan Santai',30,'Mudah',110,'30 menit tanpa henti','Jalan dengan tempo nyaman, ayun lengan, bernapas teratur.'],
['Peregangan & Mobilitas',15,'Mudah',40,'8 gerakan x 30 detik','Leher, bahu, punggung, pinggul, hamstring, betis. Jangan memaksa.'],
['Bodyweight Pemula',20,'Sedang',130,'3 set: 10 squat, 8 wall push-up, 20 dtk plank','Istirahat 45 detik antar set.'],
['Hari Istirahat',0,'-',0,'-','Istirahat total atau jalan ringan bila ingin.'],
['Kardio Ringan',20,'Mudah',120,'4 ronde: 1 mnt march, 1 mnt step-touch','Pertahankan napas masih bisa mengobrol.'],
['Yoga Stretching',20,'Mudah',70,'6 pose x 5 napas','Child pose, cat-cow, downward dog, cobra, lunge, forward fold.'],
['Jalan Cepat & Core',30,'Sedang',150,'25 mnt jalan + 2 set 10 dead-bug','Tambahkan sedikit tempo di tengah sesi.']];
const WU='Pemanasan: 3 menit gerak sendi & jalan di tempat. Pendinginan: 3 menit tarik napas + peregangan ringan.';
const dayIdx=d=>Math.round((D(d)-D(S.set.plan))/864e5);
const mod=(a,n)=>((a%n)+n)%n;
function getMeal(d,sl){const o=S.ov[d+sl];if(o)return o.del?null:o;const i=mod(dayIdx(d),30);const x=sl=='b'?i%8:sl=='l'?(3*i+1)%8:sl=='d'?(5*i+2)%8:i%4;return P[sl][x]}
const sv=()=>+S.set.serv||1;
function getWk(d){const o=S.wo[d];if(o)return o;const a=W[mod(dayIdx(d),30)%7];return{n:a[0],m:a[1],df:a[2],k:a[3],r:a[4],i:a[5]}}
const wTot=d=>(S.water[d]||[]).reduce((a,x)=>a+x.ml,0);
const medsOn=d=>S.meds.filter(m=>m.start<=d&&(!m.end||d<=m.end));
const medSlots=d=>medsOn(d).flatMap(m=>m.times.split(',').map(t=>t.trim()).filter(Boolean).map(t=>({m,t,key:m.id+'@'+t})));
const mlog=d=>S.ml[d]||{};
function tot(d){let pl=0,ea=0,p=0,c=0,f=0;['b','l','d','s'].forEach(s=>{const m=getMeal(d,s);if(!m)return;const k=m.k*sv();pl+=k;if(S.eaten[d+s]){ea+=k;p+=m.p*sv();c+=m.c*sv();f+=m.f*sv()}});return{pl:Math.round(pl),ea:Math.round(ea),p:Math.round(p),c:Math.round(c),f:Math.round(f)}}
function score(d){const mealsDone=['b','l','d'].filter(s=>S.eaten[d+s]).length;const sl=medSlots(d),tk=sl.filter(x=>(mlog(d)[x.key]||{}).s=='taken').length;const w=getWk(d);
return{w:Math.min(1,wTot(d)/S.set.water),m:mealsDone/3,e:(S.wk[d]=='done'||w.m==0&&S.wk[d]!='skip')?1:0,d:sl.length?tk/sl.length:null,any:wTot(d)>0||mealsDone>0||S.wk[d]=='done'||tk>0}}
const pct=d=>{const s=score(d),a=[s.w,s.m,s.e];if(s.d!==null)a.push(s.d);return Math.round(a.reduce((x,y)=>x+y,0)/a.length*100)};
function toast(t){const e=$('#toast');e.textContent=t;e.hidden=false;clearTimeout(toast.t);toast.t=setTimeout(()=>e.hidden=true,2500)}
const modal=h=>{$('#modal').innerHTML='<div>'+h+'</div>';$('#modal').hidden=false};
const closeM=()=>{$('#modal').hidden=true;render()};
$('#modal').addEventListener('click',e=>{if(e.target.id=='modal')closeM()});
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const ring=(p,l)=>`<div class=ring style="--p:${Math.min(100,p)}"><b>${l}</b></div>`;
const go=t=>{tab=t;render();scrollTo(0,0)};
function greet(){const h=new Date().getHours();return h<11?'Selamat pagi':h<15?'Selamat siang':h<18?'Selamat sore':'Selamat malam'}
const fdate=d=>D(d).toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
function mealRow(d,s){const m=getMeal(d,s);if(!m)return`<div class=row><div><small>${L[s]}</small><br><span>Kosong</span></div><button class=s onclick="editMeal('${d}','${s}',1)">+ Tambah</button></div>`;
return`<div class=row onclick="openMeal('${d}','${s}')"><input type=checkbox ${S.eaten[d+s]?'checked':''} onclick="event.stopPropagation();eat('${d}','${s}')"><div><small>${L[s]}</small><br>${esc(m.n)}</div><span>${Math.round(m.k*sv())} kkal</span></div>`}
function eat(d,s){S.eaten[d+s]=!S.eaten[d+s];save();render()}
function home(){const d=today(),t=tot(d),w=wTot(d),wk=getWk(d),sl=medSlots(d),tk=sl.filter(x=>(mlog(d)[x.key]||{}).s=='taken').length;
return`<div class=top><div><small>${fdate(d)}</small><h1>${greet()}${S.set.name?', '+esc(S.set.name):''} 🌿</h1></div><button onclick="settings()">⚙️</button></div>
<small>Progress, bukan kesempurnaan. Setiap langkah kecil berarti.</small>
<div class=grid style="margin-top:12px"><div class=stat>${ring(t.pl/S.set.kcal*100,t.pl)}<small>kkal direncanakan / ${S.set.kcal}</small></div>
<div class=stat>${ring(w/S.set.water*100,Math.round(w/S.set.water*100)+'%')}<small>air ${w}/${S.set.water} ml</small></div>
<div class=stat>${ring(S.wk[d]=='done'?100:0,S.wk[d]=='done'?'✓':'–')}<small>olahraga</small></div>
<div class=stat>${ring(sl.length?tk/sl.length*100:0,sl.length?tk+'/'+sl.length:'–')}<small>obat</small></div></div>
<h2>Menu hari ini</h2><div class=card>${['b','l','d','s'].map(s=>mealRow(d,s)).join('')}</div>
<h2>Air minum</h2><div class=card><div class=bar><i style="width:${Math.min(100,w/S.set.water*100)}%"></i></div>${w} / ${S.set.water} ml<div class=chips>${[200,250,300].map(n=>`<button class=s onclick="addW(${n})">+${n}</button>`).join('')}<button class=s onclick="go('health')">Lainnya</button></div></div>
<h2>Olahraga</h2><div class=card onclick="go('act')"><b>${esc(wk.n)}</b><br><small>${wk.m} menit · ${wk.df} · ${S.wk[d]=='done'?'✅ selesai':S.wk[d]=='skip'?'dilewati':'belum'}</small></div>
<h2>Obat</h2><div class=card>${sl.length?sl.sort((a,b)=>a.t<b.t?-1:1).map(x=>{const l=mlog(d)[x.key];return`<div class=row><div>${esc(x.m.n)} <small>${esc(x.m.dose)} ${esc(x.m.unit)}</small><br><small>${x.t}${l?' · '+l.s:''}</small></div>${l?'':`<button onclick="medMark('${d}','${x.key}','taken')">Sudah</button>`}</div>`}).join(''):'<small>Belum ada jadwal obat. Tambahkan di tab Kesehatan.</small>'}</div>`}
function meals(){const d=md;let h=`<div class=top><h1>Menu</h1><div><button class="s" onclick="mv='day';render()">Hari</button> <button class=s onclick="mv='week';render()">Minggu</button> <button class=s onclick="mv='month';render()">Bulan</button></div></div>
<div class=top><button onclick="md=addD(md,${mv=='day'?-1:mv=='week'?-7:-30});render()">‹</button><small>${fdate(d)}</small><button onclick="md=addD(md,${mv=='day'?1:mv=='week'?7:30});render()">›</button></div>`;
if(mv=='day'){const t=tot(d);h+=`<div class=card><b>Nutrisi (estimasi)</b><div class=bar><i style="width:${Math.min(100,t.ea/S.set.kcal*100)}%"></i></div><small>Target ${S.set.kcal} · Rencana ${t.pl} · Dimakan ${t.ea} · Sisa ${Math.max(0,S.set.kcal-t.ea)} kkal</small><br><small>Protein ${t.p} g · Karbo ${t.c} g · Lemak ${t.f} g</small></div>
<div class=card>${['b','l','d','s'].map(s=>mealRow(d,s)).join('')}</div><button class=s onclick="shop()">🛒 Daftar belanja 7 hari</button>`;
if(S.fav.length)h+=`<h2>Favorit</h2><div class=card>${S.fav.map(m=>`<div class=row><div>${esc(m.n)}</div><span>${m.k} kkal</span></div>`).join('')}</div>`}
else if(mv=='week'){h+=Array.from({length:7},(_,i)=>{const x=addD(d,i);return`<div class=card onclick="md='${x}';mv='day';render()"><b>${D(x).toLocaleDateString('id-ID',{weekday:'short',day:'numeric',month:'short'})}</b><br><small>${['b','l','d'].map(s=>(getMeal(x,s)||{n:'-'}).n).join(' · ')}</small></div>`}).join('')}
else h+=`<div class=cal>${Array.from({length:30},(_,i)=>{const x=addD(S.set.plan,i);return`<div class=d onclick="md='${x}';mv='day';render()">${D(x).getDate()}<i style="opacity:${S.eaten[x+'b']||S.eaten[x+'l']||S.eaten[x+'d']?1:.2}"></i></div>`}).join('')}</div><small>Rencana 30 hari mulai ${S.set.plan}. Ketuk hari untuk detail.</small>`;
return h+`<div class=note>Nilai gizi adalah estimasi, bukan perhitungan medis.</div>`}
function openMeal(d,s){const m=getMeal(d,s),k=sv(),fv=S.fav.some(x=>x.n==m.n);modal(`<h1>${esc(m.n)}</h1><small>${L[s]} · porsi ×${k}</small>
<p><b>${Math.round(m.k*k)} kkal</b> · P ${Math.round(m.p*k)} g · K ${Math.round(m.c*k)} g · L ${Math.round(m.f*k)} g</p>
<h2>Bahan</h2><p>${esc(m.i)}</p><h2>Cara masak</h2><p>${esc(m.s)}</p><h2>Pengganti</h2><p>${esc(m.u||'-')}</p>
<div class=chips><button onclick="eat('${d}','${s}');closeM()">${S.eaten[d+s]?'Batal dimakan':'Tandai dimakan'}</button><button class=s onclick="editMeal('${d}','${s}')">Edit</button><button class=s onclick="replMeal('${d}','${s}')">Ganti</button><button class=p onclick="fav('${d}','${s}')">${fv?'★ Hapus favorit':'☆ Favorit'}</button><button class=x onclick="S.ov['${d+s}']={del:1};save();closeM()">Hapus</button></div>`)}
function fav(d,s){const m=getMeal(d,s),i=S.fav.findIndex(x=>x.n==m.n);i>=0?S.fav.splice(i,1):S.fav.push({...m});save();closeM()}
function editMeal(d,s,neu){const m=neu?{n:'',k:0,p:0,c:0,f:0,i:'',s:'',u:''}:getMeal(d,s);modal(`<h1>${neu?'Tambah':'Edit'} ${L[s]}</h1>
${[['n','Nama'],['k','Kalori (kkal)'],['p','Protein (g)'],['c','Karbo (g)'],['f','Lemak (g)']].map(([k,l])=>`<label>${l}</label><input id=e_${k} value="${esc(m[k])}">`).join('')}
<label>Bahan & takaran</label><textarea id=e_i rows=3>${esc(m.i)}</textarea><label>Cara masak</label><textarea id=e_s rows=3>${esc(m.s)}</textarea><label>Pengganti</label><input id=e_u value="${esc(m.u)}">
<button onclick="saveMeal('${d}','${s}')">Simpan</button>`)}
function saveMeal(d,s){const g=k=>$('#e_'+k).value;if(!g('n').trim())return toast('Nama wajib diisi');S.ov[d+s]={n:g('n'),k:+g('k')||0,p:+g('p')||0,c:+g('c')||0,f:+g('f')||0,i:g('i'),s:g('s'),u:g('u')};save();closeM()}
function replMeal(d,s){const o=[...P[s],...S.fav];modal(`<h1>Ganti ${L[s]}</h1>${o.map((m,i)=>`<div class=row onclick="S.ov['${d+s}']=${esc(JSON.stringify(m)).replace(/'/g,'&#39;')};save();closeM()"><div>${esc(m.n)}</div><span>${m.k} kkal</span></div>`).join('')}`)}
function shop(){const c={};for(let i=0;i<7;i++)['b','l','d','s'].forEach(s=>{const m=getMeal(addD(md,i),s);if(m)m.i.split(',').forEach(x=>{x=x.trim();if(x)c[x]=(c[x]||0)+1})});
const av=(S.set.avoid+','+S.set.allergy).toLowerCase().split(',').map(x=>x.trim()).filter(Boolean);
modal(`<h1>Belanja 7 hari</h1><small>Dari ${md}. Item bertanda ⚠️ cocok dengan alergi/pantangan Anda.</small>${Object.entries(c).map(([k,v])=>`<div class=row><input type=checkbox><div>${av.some(a=>k.toLowerCase().includes(a))?'⚠️ ':''}${esc(k)}</div><span>×${v}</span></div>`).join('')}`)}
function act(){const d=today(),w=getWk(d),done=Object.keys(S.wk).filter(k=>S.wk[k]=='done').length,wkn=Array.from({length:7},(_,i)=>addD(d,-i)).filter(x=>S.wk[x]=='done').length;
return`<h1>Aktivitas</h1><div class=card><small>Hari ini · ${fdate(d)}</small><h2 style="margin:4px 0">${esc(w.n)}</h2><p>${w.m} menit · ${w.df} · ~${w.k} kkal (perkiraan kasar)</p><p>${esc(w.r)}</p><p><small>${esc(w.i)}</small></p><p><small>${WU}</small></p>
<div class=chips><button onclick="S.wk['${d}']='done';save();render()">✔ Selesai</button><button class=s onclick="S.wk['${d}']='skip';save();render()">Lewati</button><button class=s onclick="editWk('${d}')">Edit/Ganti</button></div><small>Status: ${S.wk[d]||'belum'}</small></div>
<div class=card><b>Konsistensi</b><br>${wkn}/7 hari terakhir · total ${done} latihan selesai</div>
<h2>7 hari ke depan</h2><div class=card>${Array.from({length:7},(_,i)=>{const x=addD(d,i),y=getWk(x);return`<div class=row><div><small>${D(x).toLocaleDateString('id-ID',{weekday:'short',day:'numeric'})}</small><br>${esc(y.n)}</div><span>${y.m} mnt</span></div>`}).join('')}</div>
<div class=note>⚠️ Hentikan latihan bila nyeri, pusing, atau gejala tidak biasa. Konsultasikan ke tenaga kesehatan bila ragu.</div>`}
function editWk(d){const w=getWk(d);modal(`<h1>Edit latihan</h1><label>Nama</label><input id=w_n value="${esc(w.n)}"><label>Durasi (menit)</label><input id=w_m type=number value="${w.m}"><label>Tingkat</label><input id=w_df value="${esc(w.df)}"><label>Perkiraan kkal</label><input id=w_k type=number value="${w.k}"><label>Repetisi/set</label><input id=w_r value="${esc(w.r)}"><label>Instruksi</label><textarea id=w_i>${esc(w.i)}</textarea>
<div class=chips><button onclick="S.wo['${d}']={n:w_n.value,m:+w_m.value||0,df:w_df.value,k:+w_k.value||0,r:w_r.value,i:w_i.value};save();closeM()">Simpan</button><button class=s onclick="delete S.wo['${d}'];save();closeM()">Kembalikan default</button></div>`)}
function addW(n){const d=today();(S.water[d]=S.water[d]||[]).push({t:hm(),ml:n});S.last=Date.now();save();render();toast('+'+n+' ml')}
function health(){const d=today(),w=wTot(d),l=S.water[d]||[],sl=medSlots(d).sort((a,b)=>a.t<b.t?-1:1);
return`<h1>Kesehatan</h1><h2>Air minum</h2><div class=card><div style="text-align:center">${ring(w/S.set.water*100,Math.round(w/S.set.water*100)+'%')}${w} / ${S.set.water} ml · sisa ${Math.max(0,S.set.water-w)} ml</div>
<div class=chips>${[100,150,200,250,300].map(n=>`<button class=s onclick="addW(${n})">+${n}</button>`).join('')}<button class=p onclick="const n=+prompt('Jumlah ml?');if(n>0)addW(n)">Kustom</button><button class=x onclick="undoW()">Undo</button></div>
<small>Riwayat: ${l.map(x=>x.t+' '+x.ml).join(' · ')||'belum ada'}</small></div>
<h2>Obat hari ini</h2><div class=card>${sl.map(x=>{const g=mlog(d)[x.key];return`<div class=row><div>${esc(x.m.n)} <small>${esc(x.m.dose)} ${esc(x.m.unit)}</small><br><small>${x.t} · ${esc(x.m.ins||'')} ${g?'· '+g.s+(g.at?' '+g.at:''):''}</small></div>${g?`<button class=s onclick="delete S.ml['${d}']['${x.key}'];save();render()">↺</button>`:`<button onclick="medMark('${d}','${x.key}','taken')">Sudah</button><button class=s onclick="medMark('${d}','${x.key}','skipped')">Lewat</button>`}</div>`}).join('')||'<small>Belum ada jadwal hari ini.</small>'}</div>
<h2>Daftar obat <button class=s onclick="editMed()">+ Tambah</button></h2><div class=card>${S.meds.map(m=>`<div class=row onclick="editMed('${m.id}')"><div>${esc(m.n)} <small>${esc(m.dose)} ${esc(m.unit)}</small><br><small>${esc(m.times)} · ${m.rem?'🔔':'🔕'}</small></div></div>`).join('')||'<small>Belum ada obat.</small>'}</div>
<button class=s onclick="medHist()">Riwayat obat</button><div class=note>DailyWell hanya mencatat jadwal yang Anda masukkan sendiri dan tidak menyarankan atau mengubah dosis obat.</div>`}
function undoW(){const d=today();(S.water[d]||[]).pop();save();render()}
function medMark(d,k,s){(S.ml[d]=S.ml[d]||{})[k]={s,at:hm()};save();render()}
function editMed(id){const m=S.meds.find(x=>x.id==id)||{n:'',dose:'',unit:'mg',ins:'',times:'08:00',start:today(),end:'',notes:'',rem:true};
modal(`<h1>${id?'Edit':'Tambah'} obat</h1>${[['n','Nama'],['dose','Dosis'],['unit','Satuan'],['ins','Instruksi (mis. sesudah makan)'],['times','Jam (pisahkan koma: 08:00,20:00)'],['notes','Catatan']].map(([k,l])=>`<label>${l}</label><input id=m_${k} value="${esc(m[k])}">`).join('')}
<label>Mulai</label><input type=date id=m_start value="${m.start}"><label>Selesai (opsional)</label><input type=date id=m_end value="${m.end||''}"><label><input type=checkbox id=m_rem ${m.rem?'checked':''}> Pengingat aktif</label>
<div class=chips><button onclick="saveMed('${id||''}')">Simpan</button>${id?`<button class=x onclick="if(confirm('Hapus?')){S.meds=S.meds.filter(x=>x.id!='${id}');save();closeM()}">Hapus</button>`:''}</div>`)}
function saveMed(id){const g=k=>$('#m_'+k).value,o={id:id||'m'+Date.now(),n:g('n').trim(),dose:g('dose'),unit:g('unit'),ins:g('ins'),times:g('times'),notes:g('notes'),start:g('start')||today(),end:g('end'),rem:$('#m_rem').checked};
if(!o.n)return toast('Nama wajib diisi');if(!/^(\d{1,2}:\d{2})(\s*,\s*\d{1,2}:\d{2})*$/.test(o.times))return toast('Format jam salah');o.times=o.times.split(',').map(t=>{const[a,b]=t.trim().split(':');return pad(a)+':'+b}).join(',');
const i=S.meds.findIndex(x=>x.id==id);i>=0?S.meds[i]=o:S.meds.push(o);save();closeM()}
function medHist(){const r=[];Object.keys(S.ml).sort().reverse().slice(0,30).forEach(d=>Object.entries(S.ml[d]).forEach(([k,v])=>{const m=S.meds.find(x=>x.id==k.split('@')[0]);r.push(`<div class=row><div>${esc(m?m.n:'(dihapus)')}<br><small>${d} · jadwal ${k.split('@')[1]}</small></div><span>${v.s} ${v.at||''}</span></div>`)}));modal('<h1>Riwayat obat</h1>'+(r.join('')||'<small>Kosong</small>'))}
function prog(){const d=today(),y=cm.getFullYear(),mo=cm.getMonth(),first=new Date(y,mo,1).getDay(),n=new Date(y,mo+1,0).getDate();
let cells=Array(first).fill('<div></div>').join('');for(let i=1;i<=n;i++){const x=y+'-'+pad(mo+1)+'-'+pad(i),s=score(x);cells+=`<div class="d ${x==d?'t':''}" onclick="dayInfo('${x}')">${i}<i style="opacity:${s.any?Math.max(.3,pct(x)/100):0}"></i></div>`}
const days7=Array.from({length:7},(_,i)=>addD(d,i-6));let st=0;for(let x=d;score(x).any||x==d&&st==0&&!score(x).any&&false;x=addD(x,-1))st++;
if(!score(d).any){st=0;for(let x=addD(d,-1);score(x).any;x=addD(x,-1))st++}
const avg=days7.reduce((a,x)=>a+pct(x),0)/7;
return`<h1>Progres</h1><div class=card><div class=top><button onclick="cm=new Date(${y},${mo-1},1);render()">‹</button><b>${cm.toLocaleDateString('id-ID',{month:'long',year:'numeric'})}</b><button onclick="cm=new Date(${y},${mo+1},1);render()">›</button></div><div class=cal>${'MSSRKJS'.split('').map(x=>`<small>${x}</small>`).join('')}${cells}</div></div>
<div class=grid><div class=stat><b>🔥 ${st}</b><small>hari aktif beruntun</small></div><div class=stat><b>${Math.round(avg)}%</b><small>rata-rata 7 hari</small></div></div>
<h2>7 hari terakhir</h2><div class=card><div class=bars>${days7.map(x=>`<div style="height:${Math.max(4,pct(x))}%"></div>`).join('')}</div><small>${days7.map(x=>D(x).getDate()).join('  ')}</small></div>
<div class=card>${[['💧 Air',s=>s.w],['🍽 Menu',s=>s.m],['🏃 Olahraga',s=>s.e]].map(([l,f])=>`<small>${l}</small><div class=bar><i style="width:${days7.reduce((a,x)=>a+f(score(x)),0)/7*100}%"></i></div>`).join('')}</div>
<small>Setiap langkah kecil berarti. Hari yang terlewat tidak apa-apa. Lanjutkan saja besok 🌱</small>`}
function dayInfo(x){const s=score(x),t=tot(x),w=getWk(x),sl=medSlots(x),tk=sl.filter(a=>(mlog(x)[a.key]||{}).s=='taken').length;
modal(`<h1>${fdate(x)}</h1><p>Ringkasan: ${pct(x)}%</p><div class=card>${['b','l','d','s'].map(k=>{const m=getMeal(x,k);return`<div class=row><div><small>${L[k]}</small><br>${esc(m?m.n:'-')}</div><span>${S.eaten[x+k]?'✓':''}</span></div>`}).join('')}</div><div class=card>🏃 ${esc(w.n)} (${w.m} mnt) · ${S.wk[x]||'belum'}<br>💧 ${wTot(x)}/${S.set.water} ml<br>💊 ${tk}/${sl.length} obat<br>🔥 ${t.ea}/${t.pl} kkal</div><button onclick="md='${x}';mv='day';tab='meals';closeM()">Buka menu hari ini</button>`)}
function settings(){const s=S.set,pm='Notification' in window?Notification.permission:'tidak didukung';
modal(`<h1>Pengaturan</h1>${[['name','Nama/panggilan'],['kcal','Target kalori (kkal)'],['water','Target air (ml)'],['serv','Jumlah porsi (pengali)'],['allergy','Alergi (pisah koma)'],['avoid','Pantangan/tidak suka (pisah koma)'],['budget','Anggaran'],['cook','Waktu masak maks (menit)'],['rs','Pengingat air mulai (HH:MM)'],['re','Pengingat air selesai'],['ri','Interval (menit)'],['quiet','Jam tenang (mis. 12:00-13:00)'],['plan','Tanggal mulai rencana 30 hari']].map(([k,l])=>`<label>${l}</label><input id=s_${k} value="${esc(s[k])}">`).join('')}
<label><input type=checkbox id=s_ron ${s.ron?'checked':''}> Pengingat air aktif</label>
<div class=note><b>Notifikasi:</b> izin = <b>${pm}</b>. Tanpa server, notifikasi hanya bisa muncul saat aplikasi terbuka/aktif di latar. Android bisa menghentikan aplikasi di latar, jadi pengingat <u>tidak dijamin</u> saat aplikasi tertutup. Untuk obat penting, pasang alarm di aplikasi Jam sebagai cadangan.</div>
<div class=chips><button onclick="saveSet()">Simpan</button><button class=s onclick="askNotif()">Izinkan notifikasi</button><button class=s onclick="testNotif()">Tes notifikasi</button></div>
<h2>Data</h2><div class=chips><button class=s onclick="exp()">Ekspor</button><button class=s onclick="$('#imp').click()">Impor</button><button class=x onclick="if(confirm('Hapus SEMUA data?')){localStorage.removeItem(K);S=def();closeM()}">Hapus semua</button></div><input id=imp type=file accept=.json hidden onchange="imp(this.files[0])">`)}
function saveSet(){const s=S.set;['name','allergy','avoid','budget','cook','rs','re','quiet','plan'].forEach(k=>s[k]=$('#s_'+k).value);['kcal','water','ri'].forEach(k=>s[k]=+$('#s_'+k).value||s[k]);s.serv=+$('#s_serv').value||1;s.ron=$('#s_ron').checked;save();closeM();toast('Tersimpan')}
async function askNotif(){if(!('Notification' in window))return toast('Browser tidak mendukung notifikasi');const r=await Notification.requestPermission();toast('Izin: '+r);settings()}
function notify(t,b){if(!('Notification' in window)||Notification.permission!=='granted'){toast(t+' — '+b);return false}
(reg?reg.showNotification(t,{body:b,icon:'icons/icon-192.png',badge:'icons/icon-192.png',tag:t}):Promise.resolve(new Notification(t,{body:b}))).catch(()=>toast(t));return true}
function testNotif(){if(!notify('DailyWell','Tes notifikasi berhasil 🌿'))toast('Izin belum diberikan — hanya notifikasi dalam aplikasi')}
function exp(){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(S)],{type:'application/json'}));a.download='dailywell-'+today()+'.json';a.click()}
function imp(f){if(!f)return;f.text().then(t=>{try{const o=JSON.parse(t);if(!o.set)throw 0;S=Object.assign(def(),o);save();closeM();toast('Impor berhasil')}catch(e){toast('File tidak valid')}})}
const fired={};
function tick(){const d=today(),n=hm();
medSlots(d).forEach(x=>{if(x.m.rem&&x.t==n&&!mlog(d)[x.key]&&!fired[d+x.key]){fired[d+x.key]=1;notify('Waktunya obat 💊',x.m.n+' '+x.m.dose+' '+x.m.unit)}});
const s=S.set;if(s.ron&&n>=s.rs&&n<=s.re&&Date.now()-S.last>=s.ri*6e4){const q=(s.quiet||'').split('-');if(!(q.length==2&&n>=q[0]&&n<=q[1])&&wTot(d)<s.water){S.last=Date.now();save();notify('Minum air 💧','Yuk minum segelas air.')}}}
function render(){$('#app').innerHTML={home,meals,act,health,prog}[tab]();
$('#nav').innerHTML=[['home','🏠','Home'],['meals','🍽','Menu'],['act','🏃','Aktivitas'],['health','💧','Kesehatan'],['prog','📈','Progres']].map(([k,i,l])=>`<button class="${tab==k?'on':''}" onclick="go('${k}')"><span>${i}</span>${l}</button>`).join('')}
if('serviceWorker' in navigator)navigator.serviceWorker.register('sw.js').then(r=>reg=r).catch(()=>{});
setInterval(tick,30000);document.addEventListener('visibilitychange',()=>{if(!document.hidden){render();tick()}});
render();
