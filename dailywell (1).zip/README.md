# DailyWell 🌿
PWA wellness planner (menu 30 hari, air, olahraga, obat, kalender, progres). Tanpa build, tanpa server, tanpa akun. Data tersimpan di HP (localStorage).

## Deploy gratis (GitHub Pages)
1. Daftar gratis di github.com → **New repository** → nama `dailywell`, Public.
2. **uploading an existing file** → seret SEMUA isi folder ini (index.html, app.js, style.css, sw.js, manifest.json, folder icons) → Commit.
3. **Settings → Pages** → Source: *Deploy from a branch* → Branch `main`, folder `/ (root)` → Save.
4. Tunggu 1–2 menit. Alamat: `https://USERNAME.github.io/dailywell/`

## Pasang di Android
Buka alamat di Chrome → menu ⋮ → **Install app / Tambahkan ke layar utama**.

## Notifikasi (jujur)
Tanpa server, notifikasi hanya andal saat aplikasi terbuka/aktif. Android dapat menghentikan aplikasi di latar. Notifikasi terjadwal yang dijamin butuh Web Push (server) — tidak dipakai agar 100% gratis. Gunakan alarm Jam sebagai cadangan obat penting.

## Troubleshooting
- Tombol Install tidak muncul: pastikan HTTPS (github.io) dan buka di Chrome.
- Perubahan tidak muncul setelah update: ubah `C='dailywell-v1'` di sw.js jadi v2, lalu muat ulang.
- Data hilang: gunakan Pengaturan → Ekspor secara berkala.
